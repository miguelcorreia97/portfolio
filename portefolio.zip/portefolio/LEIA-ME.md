# Portefólio de Miguel Correia

## 1. Juntar as imagens

Cria duas pastas ao lado do `index.html`: `images` e `videos` (a pasta `fonts` já vem incluída e não deve ser apagada). Põe lá os teus trabalhos com estes nomes exatos (tudo em minúsculas, sem acentos):

| Ficheiro | O que é |
|---|---|
| `images/foto.png` | A tua foto, recortada e com fundo transparente (podes usar o remove.bg) |
| `images/matchday.jpg` | Cartaz de dia de jogo |
| `images/onze-inicial.jpg` | Onze inicial |
| `images/resultado.jpg` | Resultado final |
| `images/futebol-4.jpg`, `futebol-5.jpg` | Mais duas peças de futebol |
| `images/cel-1.jpg`, `cel-2.jpg` | Ciência e Letras |
| `images/cic-1.jpg` | Católica Investment Club |
| `images/nexalyse-1.jpg` | Nexalyse |
| `images/rupto-1.jpg` | RuptoWear |
| `videos/desporto.mp4` | Vídeo de design desportivo (opcional; se não existir, o espaço desaparece) |

Os trabalhos de futebol ficam melhor em formato 4:5 (por exemplo 1080 x 1350 px, o tamanho dos posts de Instagram). Todos os trabalhos aparecem nesse formato na grelha.

Enquanto uma imagem faltar, o site mostra uma moldura tracejada com o nome do ficheiro. Assim que a imagem estiver na pasta certa, aparece sozinha.

## 2. Publicar no GitHub Pages (grátis)

1. Cria uma conta em github.com.
2. Cria um repositório novo chamado `miguelcorreia.github.io` (troca `miguelcorreia` pelo teu nome de utilizador do GitHub). Marca-o como público.
3. No repositório, clica em **Add file > Upload files** e arrasta o `index.html` e as pastas `fonts`, `images` e `videos`. Clica em **Commit changes**.
4. Vai a **Settings > Pages** e confirma que a fonte é o ramo `main`.
5. Em um ou dois minutos o site fica disponível em `https://miguelcorreia.github.io`.

## 3. Domínio próprio (opcional)

Se comprares um domínio (por exemplo `miguelcorreia.pt`), escreve-o em **Settings > Pages > Custom domain** e segue as instruções do GitHub para ligar o domínio.

## Para mudar textos

Abre o `index.html` num editor de texto (por exemplo o VS Code), muda o texto e volta a carregar o ficheiro no GitHub. Ou pede-me a mudança e envio-te o ficheiro atualizado.
